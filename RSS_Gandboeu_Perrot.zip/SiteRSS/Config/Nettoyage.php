<?php

class Nettoyage{

	public static function netString($string){
		return filter_var($string,FILTER_SANITIZE_STRING);
	}

	public static function netMdp($mdp){
		return filter_var($mdp,FILTER_VALIDATE_REGEXP,array("options"=>array("regexp"=> "/[A-Za-z0-9]{6,20}/")));
	}
		
	public static function netUrl($url){
		return filter_var($url,FILTER_SANITIZE_URL);
	}

    public static function netInt($int){
        return filter_var($int,FILTER_SANITIZE_NUMBER_INT);
    }
}
?>

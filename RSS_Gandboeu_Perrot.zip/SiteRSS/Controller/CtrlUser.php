<?php


class CtrlUser
{
    function __construct(){

        $dataVueErreur = array();

        $action = $_REQUEST['action'];

        switch ($action)
        {
            case null :
                $this->afficheNews();
                break;

            case 'categorie':
                $this->categorie();
                break;


            case 'titre':
                $this->titre();
                break;

            case 'connexion':
                $this->connexion();
                    break;

            case 'admin':
                require ('Vue/adminLog.php');
                break;

            case 'page':
                $this->nouvelpage();
                break;

            default:
                $dataVueErreur[] = 'Probleme appel php';
                require('Vue/erreur.php');
                break;

        }

        exit(0);

    }

    function categorie()
    {
        $cate=Validation::validation_string($_POST['cate']);
        $model = new ModeleUsr();
        $data = $model->getNews_categorie($cate);
        if(isset($data)&&$data!=null) require ("Vue/vue.php");
        else {
            $dataVueErreur[] = 'Pas de news de cette catégorie';
            require("Vue/erreur.php");
        }
    }

    function titre()
    {
        $rech=Validation::validation_string($_POST['recherche']);
        //$rech='%'.$rech.'%';
        $model = new ModeleUsr();
        $data = $model->getNews_titre($rech);
        if(isset($data)&&$data!=null) require ("Vue/vue.php");
        else {
            $dataVueErreur[] = 'Pas de news de ce nom';
            require("Vue/erreur.php");
        }
    }

    function nouvelpage()
    {
        global $pageA;
        $pageA=Validation::validation_Int($_GET['page']);
        $this->afficheNews();
    }

    function afficheNews()
    {
        $model = new ModeleUsr();
        $data = $model->get_AllNews();
        $total = $model->countNews();
        require("Vue/vue.php");
    }

    function connexion()
    {
        global $adm;

        $login=Validation::validation_string($_POST['log']);
        $mdp=Validation::validation_mdp($_POST['mdp']);
        $model = new ModeleAdmin();
        if($model->connexion($login,$mdp))
        {
            $adm=true;
            $this->afficheNews();
        }
        else {
            $dataVueErreur[] = 'Pb connexion';
            require("Vue/erreur.php");
        }
    }

}
?>
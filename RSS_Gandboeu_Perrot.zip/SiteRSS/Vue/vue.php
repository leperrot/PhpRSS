<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>RSS master</title>

    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/side/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="bootstrap/side/css/simple-sidebar.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
    <?php
    global $newsParPage,$pageA;
    if(isset($total)){
        $nbPages=ceil($total[0]['COUNT(*)']/$newsParPage);
        if(isset($_GET['page']))
        {
            $pageA=intval($_GET['page']);

            if($pageA>$nbPages)
            {
                $pageA=$nbPages;
            }
        }
        else
        {
            $pageA=1;
        }
    }

    ?>
    <div id="wrapper">
        <!-- Sidebar -->
        <div id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand">
                    <a href="index.php">
                        RSS
                    </a>
                </li>
                <li>
                    <a href="index.php">Dernières News</a>
                </li>
                <li>
                    <form method="post" action="index.php?action=titre">
                        <div class="input-group">
                            <input type="text" name="recherche" class="form-control" placeholder="Rechercher...">
                        </div>
                    </form>
                </li>
                <li>
                    <a href="index.php?action=categorie&cate=Nouvelles technologies">Nouvelles technologies</a>
                </li>
                <li>

                    <a href="index.php?action=categorie&cate=Informatique">Informatique</a>
                </li>
                <li>
                    <a href="index.php?action=categorie&cate=Jeux vidéos">Jeux vidéos</a>
                </li>
                <li>
                    <a href="index.php?action=categorie&cate=Culture">Culture</a>
                </li>
                <li>
                    <a href="index.php?action=categorie&cate=Science">Science</a>
                </li>
                <li>
                    <a href="index.php?action=categorie&cate=Monde">Monde</a>
                </li>
                <li>
                    <a href="index.php?action=admin">Accès admin</a>
                </li>
                <?php
                global $adm;
                if($adm) echo "<li><a href=\"index.php?action=deconnexion\">Déconnexion</a></li>";
                ?>
            </ul>
        </div>

        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <h3>Nouveaux fils</h3>
                <?php
                global $adm;
                if($adm){
                echo "<form method=\"post\" action=\"index.php?action=Vajout\">
                      <span><a href=\"index.php?action=Vajout\"><button type=\"button\" class=\"btn btn-default\" aria-label=\"Left Align\">
                      <span class=\"glyphicon glyphicon-plus\" aria-hidden=\"true\"></span>
                      </button></a></span></form>";
                }
                ?>
                <div class="row">
                    <ul class="list-group">
                        <?php
                        if(isset($data)) {
                            foreach ($data as $news) {
                                echo "<li class=\"list-group\">
                                     <a href=". $news->getLien() . " >" . $news->getTitre() . "</a> 
                                     <span>".$news->getDescription()."</span>
                                     <span>".$news->getDate()."</span>";
                                global $adm;
                                if($adm){
                                    $lien=$news->getLien();
                                    echo "<span><a href=\"index.php?action=supprimer&lien=$lien\"><button type=\"button\" class=\"btn btn-default\" aria-label=\"Left Align\">
                                          <span class=\"glyphicon glyphicon-minus\" aria-hidden=\"true\"></span>
                                          </button></a></span>";
                                }
                                echo "</li>";
                            }
                        }
                        ?>
                    </ul>
                </div>
                <?php
                global $nbPages;
                echo '<p align="center">';
                if($pageA==1){
                    $pageP=$pageA+1;
                    echo "[ ".$pageA." ] <span><a href=\"index.php?action=page&page=".$pageP."\">".$pageP."</a></span>";
                }
                else
                {
                    $pageP=$pageA+1;
                    $pageM=$pageA-1;
                    echo "<span><a href=\"index.php?action=page&page=".$pageM."\">".$pageM."</a></span>
                         [ ".$pageA." ] <span><a href=\"index.php?action=page&page=".$pageP."\">".$pageP."</a></span>";
                }

                echo '</p>';
                ?>
            </div>
            <!-- /#page-content-wrapper -->
        </div>
        <!-- /#wrapper -->
    </div>

    <!-- jQuery -->
    <script src="bootstrap/side/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/side/js/bootstrap.min.js"></script>

</body>
<footer>
    <p align="center">Site réalisé par PERROT Léandre et GANDBOEUF Bastien</p>
</footer>

</html>

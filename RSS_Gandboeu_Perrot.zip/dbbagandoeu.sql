-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 10 Janvier 2017 à 21:28
-- Version du serveur :  5.7.14
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `dbbagandoeu`
--

-- --------------------------------------------------------

--
-- Structure de la table `tadmin`
--

CREATE TABLE `tadmin` (
  `login` varchar(20) NOT NULL,
  `mdp` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tadmin`
--

INSERT INTO `tadmin` (`login`, `mdp`) VALUES
('king', 'azertyui1');

-- --------------------------------------------------------

--
-- Structure de la table `tflux`
--

CREATE TABLE `tflux` (
  `Lien` varchar(250) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tflux`
--

INSERT INTO `tflux` (`Lien`) VALUES
('http://www.lemonde.fr/culture/rss_full.xml');

-- --------------------------------------------------------

--
-- Structure de la table `tnews`
--

CREATE TABLE `tnews` (
  `Lien` varchar(200) CHARACTER SET utf8 NOT NULL,
  `Titre` varchar(200) CHARACTER SET utf8 NOT NULL,
  `Date` varchar(200) CHARACTER SET utf8 NOT NULL,
  `Description` varchar(250) CHARACTER SET utf8 DEFAULT NULL,
  `Categorie` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `tnews`
--

INSERT INTO `tnews` (`Lien`, `Titre`, `Date`, `Description`, `Categorie`) VALUES
('http://9gag.com/', '9gag', '2016-12-13', 'WOW', 'Culture'),
('https://www.youtube.com/?gl=FR&hl=fr', 'Youtube', '2017-01-08', 'Vidéos en tous genres.', 'Informatique'),
('http://getbootstrap.com/components/', 'Bootstrap', '2017-01-08', 'Easy html', 'Nouvelles technologies'),
('utm_campaign=rss_link_fr', 'Enfants dÃ©placÃ©s dâ€™Alep-Est : dans la dÃ©tresse, blessÃ©s et abandonnÃ©s', 'Thu, 29 Dec 2016 14:13:38 -0500', 'ALEP, RÃ©publique arabe syrienne, 29 dÃ©cembre 2016 â€“ Pour les familles qui ont fui les combats Ã  A...', NULL),
('http://www.lemonde.fr/televisions-radio/article/2017/01/10/tv-clandestins-d-autres-vies-que-les-votres_5060562_1655027.html', 'Â«Â Clandestins, dâ€™autres vies que les vÃ´tresÂ Â»', 'Tue, 10 Jan 2017 17:43:12 +0100', 'Ã©cit de cinq sans papier qui, malgrÃ© leur dignitÃ© bafouÃ©e, se battent avec courage et tÃ©nacitÃ© pour sâ€™intÃ©grer (sur France 2 Ã  23 heures).', NULL),
('http://www.lemonde.fr/televisions-radio/article/2017/01/10/tv-le-difficile-combat-des-adolescents-transgenres_5060555_1655027.html', 'Â : Le difficile combat des adolescents transgenres', 'Tue, 10 Jan 2017 17:30:17 +0100', 'Ã©, LorÃ¨ne Debaisieux confronte, Ã  travers les tÃ©moignages de jeunes et de leurs parents, la situation en France et au Pays Bas (sur France 5 Ã  20Â hÂ 45).', NULL),
('http://www.lemonde.fr/cinema/video/2017/01/10/the-birth-of-a-nation-un-cas-d-ecole-de-formalisme-hollywoodien_5060527_3476.html', 'Â«Â The Birth of a NationÂ Â»Â : un cas dâ€™Ã©cole de formalisme hollywoodienÂ ?', 'Tue, 10 Jan 2017 17:04:49 +0100', 'Ã¨s le multioscarisÃ© Â«Â 12 Years a SlaveÂ Â», Hollywood porte de nouveau lâ€™esclavage Ã  lâ€™Ã©cran avec Â«Â The Birth of a NationÂ Â», qui peine Ã  convaincre les critiques.', NULL),
('http://www.lemonde.fr/televisions-radio/article/2017/01/10/tv-meurtre-et-manipulation-en-altitude_5060511_1655027.html', 'TV : Meurtre et manipulation en altitude', 'Tue, 10 Jan 2017 16:54:01 +0100', 'Ã¨s bien interprÃ©tÃ©e, la sÃ©rie Â«Â GlacÃ©Â Â», adpatÃ©e du premier roman de Bernard Minier, aurait gagnÃ© Ã  Ãªtre plus resserrÃ©e (sur M6 Ã  21Â heures).', NULL),
('http://www.lemonde.fr/televisions-radio/article/2017/01/10/tv-litterature-a-la-hussarde_5060463_1655027.html', 'Â : LittÃ©rature Ã  la hussarde', 'Tue, 10 Jan 2017 15:28:31 +0100', 'Ã®ne Histoire rend hommage Ã  lâ€™Ã©crivain Michel DÃ©on Ã  travers un documentaire consacrÃ© aux Â«Â HussardsÂ Â», gÃ©nÃ©ration qui marqua lâ€™aprÃ¨s-guerre et bien au-delÃ  (sur Histoire Ã  21Â hÂ 50)', NULL),
('http://www.lemonde.fr/culture/article/2017/01/10/montebourg-devoile-son-made-in-france-culturel_5060194_3246.html', 'Ã©voile son Â«Â made in FranceÂ Â» culturel', 'Tue, 10 Jan 2017 10:14:55 +0100', 'Ã  la primaire de gauche propose dâ€™augmenter de 2,5 milliards le budget de la rue de Valois et de crÃ©Ã©er une agence nationale pour lâ€™Ã©ducation artistique.', NULL),
('http://www.lemonde.fr/cinema/portfolio/2017/01/10/sur-les-ecrans-dalida-entre-les-frontieres-harmonium_5060183_3476.html', 'Ã©crans : Â«Â DalidaÂ Â Â», Â« Entre les frontiÃ¨res Â», Â«Â HarmoniumÂ Â»', 'Tue, 10 Jan 2017 10:04:53 +0100', 'â€™affiche : un biopic sur Dalida, un documentaire sur un atelier de thÃ©Ã¢tre dans un camp de rÃ©fugiÃ©s en IsraÃ«l, un film japonais sur la mauvaise conscience...', NULL),
('http://www.lemonde.fr/cinema/article/2017/01/10/dalida-mourir-sur-scene-revivre-a-l-ecran_5060107_3476.html', 'Â«Â DalidaÂ Â»Â : mourir sur scÃ¨ne, revivre Ã  lâ€™Ã©cran', 'Tue, 10 Jan 2017 09:30:37 +0100', 'Ã©alisatrice Lisa Azuelos rÃ©active le mythe de la chanteuse morte enÂ 1987 en la rÃ©duisant au statut dâ€™image.', NULL),
('http://www.lemonde.fr/bande-dessinee/article/2017/01/10/t-es-sur-qu-on-est-mardi-episode-27_5060048_4420272.html', 'â€™es sÃ»r quâ€™on est mardiÂ ?, Ã©pisode 27', 'Tue, 10 Jan 2017 06:51:40 +0100', NULL, NULL),
('http://www.lemonde.fr/televisions-radio/article/2017/01/10/de-la-rage-de-l-amour-et-de-l-amitie-notre-selection-de-series_5060046_1655027.html', 'Ã©lection de sÃ©ries duÂ Â« MondeÂ Â»', 'Tue, 10 Jan 2017 06:47:16 +0100', 'Ã©ries Ã  (re) dÃ©couvrir.', NULL),
('http://www.lemonde.fr/musiques/article/2017/01/09/le-groupe-de-rap-iam-annonce-la-sortie-d-un-nouvel-album-en-mars_5059955_1654986.html', 'â€™un nouvel album Â«Â RÃªvolutionÂ Â» en mars', 'Mon, 09 Jan 2017 18:20:13 +0100', 'Ãªte cette annÃ©e les vingt ans de lâ€™album mythique Â«Â Lâ€™Ecole du micro dâ€™argentÂ Â». La pochette de leur nouvel album est ornÃ©e dâ€™un micro en forme de poing levÃ©.', NULL),
('http://www.lemonde.fr/videos/video/2017/01/09/meryl-streep-critique-donald-trump-lors-des-golden-globes_5059807_1669088.html', 'Meryl Streep critique Donald Trump lors des Golden Globes', 'Mon, 09 Jan 2017 12:54:39 +0100', 'Ã©compensÃ©e pour lâ€™ensemble de sa carriÃ¨re, lâ€™actrice amÃ©ricaine a profitÃ© de la cÃ©rÃ©monie des Golden Globes pour fustiger lâ€™attitude de Donald Trump. Lequel sâ€™est empressÃ© de rÃ©agir sur Twitter.', NULL),
('http://www.lemonde.fr/arts/article/2017/01/09/les-attentats-de-2015-ont-pese-sur-la-frequentation-des-musees-parisiens_5059635_1655012.html', 'Ã©es parisiens', 'Mon, 09 Jan 2017 08:56:31 +0100', 'â€™annÃ©e a Ã©tÃ© marquÃ©e par une reprise, celle-ci ne comble pas le dÃ©ficit qui sâ€™est creusÃ© depuis novembreÂ 2015.', NULL),
('http://www.lemonde.fr/musiques/article/2017/01/09/une-chanson-un-concert-un-festival-et-un-docu-pour-en-prendre-plein-les-oreilles_5059603_1654986.html', 'Ã©lection musiques duÂ Â« MondeÂ Â»', 'Mon, 09 Jan 2017 06:49:19 +0100', 'Ã©pites musicales.', NULL),
('http://www.lemonde.fr/bande-dessinee/article/2017/01/09/les-experts-du-monde-episode-25_5059590_4420272.html', 'Â«Â MondeÂ Â», Ã©pisode 25', 'Mon, 09 Jan 2017 06:46:13 +0100', NULL, NULL),
('http://www.lemonde.fr/arts/article/2017/01/09/succes-de-frequentation-pour-l-expo-chtchoukine-prolongee-de-deux-semaines_5059568_1655012.html', 'Ã¨s de frÃ©quentation pour lâ€™expo Chtchoukine, prolongÃ©e de deux semaines', 'Mon, 09 Jan 2017 06:21:55 +0100', 'Â 000Â visiteurs en dix semaines dâ€™ouverture.', NULL),
('http://www.lemonde.fr/oscars-cesars-ceremonies/portfolio/2017/01/09/retour-en-images-sur-le-palmares-des-golden-globes-2017_5059565_5040963.html', 'Ã¨s des Golden Globes 2017', 'Mon, 09 Jan 2017 05:25:15 +0100', 'Ã©rÃ©monie, qui prÃ©cÃ¨de dâ€™un mois les Oscars et rÃ©compense aussi bien la tÃ©lÃ©vision que le septiÃ¨me art, sâ€™est dÃ©roulÃ©e dimanche Ã  Beverly Hills', NULL),
('http://www.lemonde.fr/oscars-cesars-ceremonies/article/2017/01/09/jimmy-fallon-donne-le-coup-d-envoi-de-la-ceremonie-des-golden-globes_5059533_5040963.html', 'Â« La La Land Â» et Â« Elle Â» donnent le Â« la Â»', 'Mon, 09 Jan 2017 02:25:11 +0100', 'Ã§u le prix de la meilleure actrice dramatique pour Â«Â ElleÂ Â», sacrÃ© meilleur film Ã©tranger.', NULL),
('http://www.lemonde.fr/disparitions/article/2017/01/08/le-chanteur-britannique-peter-sarstedt-auteur-de-where-do-you-go-to-my-lovely-est-mort_5059517_3382.html', 'Â«Â Where Do You Go To My LovelyÂ Â», estÂ mort', 'Sun, 08 Jan 2017 22:43:11 +0100', 'â€™auteur-compositeur, qui a Ã©crit son tube en 1969, est mort Ã  lâ€™Ã¢ge de 75 ans des suites dâ€™une longue maladie rare.', NULL),
('http://www.lemonde.fr/oscars-cesars-ceremonies/article/2017/01/08/golden-globes-2017-le-film-la-la-land-part-favori_5059418_5040963.html', 'Â : le film Â«Â La La LandÂ Â» part favori', 'Sun, 08 Jan 2017 07:42:33 +0100', 'Ã©rÃ©monie, qui prÃ©cÃ¨de dâ€™un mois les Oscars et rÃ©compense aussi bien la tÃ©lÃ©vision que le septiÃ¨me art se dÃ©roule dans la nuit de dimanche Ã  lundi.', NULL);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `tflux`
--
ALTER TABLE `tflux`
  ADD PRIMARY KEY (`Lien`),
  ADD UNIQUE KEY `Lien` (`Lien`);

--
-- Index pour la table `tnews`
--
ALTER TABLE `tnews`
  ADD PRIMARY KEY (`Lien`),
  ADD UNIQUE KEY `Lien` (`Lien`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

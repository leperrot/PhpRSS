<?php
/**
 * Created by PhpStorm.
 * User: bagandboeu
 * Date: 07/12/16
 * Time: 15:09
 */

$dsn='mysql:host=localhost;dbname=dbprojectphp';
$name='root';
$mdp='';
/*$dsn='mysql:host=hina;dbname=dbbagandboeu';
$name='bagandboeu';
$mdp='1996B13g';*/


?>
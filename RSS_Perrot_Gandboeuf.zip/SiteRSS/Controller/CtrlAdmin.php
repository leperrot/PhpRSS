<?php
    /**
     * Created by PhpStorm.
     * User: bagandboeu
     * Date: 07/12/16
     * Time: 15:00
     */

class CtrlAdmin
{
    function __construct()
    {
        $dataVueErreur = array();

        $action = $_REQUEST['action'];

        switch ($action)
        {

            case null:
                $this->afficheNews();
                break;

            case 'Vajout':
                require ('Vue/formAjout.php');
                break;

            case 'ajouter':
                $this->ajouter();
                break;

            case 'ajouterF':
                $this->ajouterF();
                break;

            case 'supprimer':
                $this->supprimer();
                break;

            case 'deconnexion':
                $this->deconnexion();
                break;


            default:
                $dataVueErreur[] = 'Probleme appel php';
                require('Vue/erreur.php');
                break;
        }
        exit(0);
    }

    function afficheNews()
    {
        $model = new ModeleUsr();
        $data = $model->get_AllNews();
        require("Vue/vue.php");
    }

    function ajouter()
    {
        $lien=Validation::validation_Url($_POST['lien']);
        $titre=Validation::validation_string($_POST['titre']);
        $date=Validation::validation_string($_POST['date']);
        $desc=Validation::validation_string($_POST['desc']);
        $cate=Validation::validation_string($_POST['cate']);
        $model = new ModeleAdmin();
        $dataVueErreur[] = $model->insert_News($lien,$titre,$date,$desc,$cate);
        require("Vue/erreur.php");
    }

    function ajouterF()
    {
        $lien=Validation::validation_Url($_POST['lien']);
        $model = new ModeleAdmin();
        $dataVueErreur[] = $model->ajouterFlux($lien);
        require("Vue/erreur.php");
    }

    function deconnexion()
    {
        global $adm;
        ModeleAdmin::deconnexion();
        $adm=false;
        $this->afficheNews();
    }

    function supprimer()
    {
        $lien=Validation::validation_Url($_POST['lien']);
        $model = new ModeleAdmin();
        $dataVueErreur[] = $model->delete_lien($lien);
        require ("Vue/erreur.php");
    }

}
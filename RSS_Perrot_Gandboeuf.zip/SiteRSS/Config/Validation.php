<?php 

class Validation
{
		
	public static function validation_string($str){
		if(isset($str))
			return Nettoyage::netString($str);
		return FALSE;
	}
		
	public static function validation_mdp($mdp){
		if(isset($mdp))
			return Nettoyage::netMdp($mdp);
		return FALSE;
    }
		
	public static function validation_Url($url){
		if(isset($url))
            if(filter_var($url,FILTER_VALIDATE_URL))
            	return Nettoyage::netUrl($url);
		return FALSE;
	}

    public static function validation_Bool($bool){
        if(isset($bool))
        	if(filter_var($bool,FILTER_VALIDATE_BOOLEAN))
        		return $bool;
		return FALSE;
    }

    public static function validation_Int($int){
        if(isset($int))
        	if(filter_var($int,FILTER_VALIDATE_INT))
            	return Nettoyage::netInt($int);
		return FALSE;
    }
}

?>

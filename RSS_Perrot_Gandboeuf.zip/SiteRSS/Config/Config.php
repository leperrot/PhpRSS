<?php
/**
 * Created by PhpStorm.
 * User: bagandboeu
 * Date: 07/12/16
 * Time: 15:09
 */

/*$dsn='mysql:host=hina;dbname=dbbagandboeu';
$name='bagandboeu';
$mdp='1996B13g';*/
$dsn='mysql:host=localhost;dbname=dbprojectphp';
$name='root';
$mdp='';

$newsParPage=30;
$pageA=1;

?>